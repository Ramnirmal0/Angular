import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  fname:any;
  mname:any;
  lname:any;
  username:any;
  emailid:any;
  mobile:any;
  address:any;
  password:any;

  constructor() { }

  ngOnInit(): void {
  }

  signup(){
    console.log("Account Created : \n FullName : ",this.fname," ",this.mname," ",this.lname,"\n Username : ",this.username,"\n Email Address : ",this.emailid,"\n Mobile Number : ", this.mobile , "\n Full Address : ",this.address,"\n Password : ",this.password);
  }
}
