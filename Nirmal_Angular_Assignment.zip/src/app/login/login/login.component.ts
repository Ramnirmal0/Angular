import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  username:any;
  password:any;

  constructor() { }

  ngOnInit(): void {
  }
  login(){
    console.log("Form Input Values : Username ",this.username , " | password :", this.password);
    if(this.username=="nirmal" && this.password=="nirmal@admin"){
      console.log("login sucess");
    }else{
      console.log("login failed");
    }
    }

}




